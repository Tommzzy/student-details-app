plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.example.studentdetailsapp" // Ensure the namespace is defined here
    compileSdk = 30

    defaultConfig {
        applicationId = "com.example.studentdetailsapp"
        minSdk = 21
        targetSdk = 30
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation(kotlin("stdlib", "1.8.0"))
    // Other dependencies...
}
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.5.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.8.0")
        classpath("com.google.gms:google-services:4.3.15") // Add this line
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
