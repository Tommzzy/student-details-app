pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
    plugins {
        id("com.android.application") version "8.5.0"
        kotlin("android") version "1.8.0"
    }
}

rootProject.name = "StudentDetailsApp2"
include(":app")
