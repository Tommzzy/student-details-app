// App-level build.gradle.kts
plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    compileSdk = 34 // Use the appropriate SDK version

    namespace = "com.example.studentdetailsapp" // Specify your namespace here

    defaultConfig {
        applicationId = "com.example.studentdetailsapp"
        minSdk = 21 // Adjust as necessary
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.compose.ui:ui:1.5.0") // UI components
    implementation("androidx.compose.material:material:1.5.0") // Material Design components
    implementation("androidx.compose.ui:ui-tooling-preview:1.5.0") // Preview support
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2") // Lifecycle support
    implementation("androidx.activity:activity-compose:1.7.0") // Activity Compose support
    implementation("com.google.android.material:material:1.10.0") // Add Material Components
    // Other dependencies...
}
